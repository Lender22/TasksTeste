package br.sp.gov.etesp.tasks.utils;

public enum StatusTarefa {
ABERTO,
FECHADO

}
