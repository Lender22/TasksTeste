package br.sp.gov.etesp.tasks;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TasksApplicationTests {

	@Test
	void contextLoads() {
	}

}
